//
//  categoryCollectionViewCell.swift
//  ecommerce
//
//  Created by viswas on 27/06/22.
//

import UIKit

class categoryCollectionViewCell: UICollectionViewCell {
    
    
    
    @IBOutlet var catergoryImage: UIImageView!
    @IBOutlet var categoryName: UILabel!
    
}
