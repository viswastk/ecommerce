//
//  bannerCollectionViewCell.swift
//  ecommerce
//
//  Created by viswas on 27/06/22.
//

import UIKit

class bannerCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var bannerImage: UIImageView!
}
