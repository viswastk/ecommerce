//
//  category_model.swift
//  ecommerce
//
//  Created by viswas on 04/07/22.
//

import Foundation
class category_model
{
    var name:String?
    var image_url:String?
    
    
    func set(name:String?,image_url:String?)
    {
        self.name=name
        self.image_url=image_url
    }
}
