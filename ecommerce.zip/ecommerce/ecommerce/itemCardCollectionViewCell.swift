//
//  itemCardCollectionViewCell.swift
//  ecommerce
//
//  Created by viswas on 27/06/22.
//

import UIKit

class itemCardCollectionViewCell: UICollectionViewCell {
    @IBOutlet var cardView: UIView!
    
    @IBOutlet var addButton: UIButton!
    @IBOutlet var descriptionLabel: UILabel!
    @IBOutlet var newPrizeLabel: UILabel!
    @IBOutlet var oldPrizeLabel: UILabel!
    @IBOutlet var productImage: UIImageView!
    @IBOutlet var whishListButton: UIButton!
    @IBOutlet var offerLabel: UILabel!
    
    @IBOutlet var expressImage: UIImageView!
}
