//
//  Home.swift
//  ecommerce
//
//  Created by viswas on 27/06/22.
//
    
import UIKit

class Home: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    
    
    var newsarray:[AnyObject]?
    var categoryData:[AnyObject]?
    var bannerData:[AnyObject]?
    var itemsData:[AnyObject]?
    let screenSize: CGRect = UIScreen.main.bounds
    var bannerArray:[banner_model]=[]
    var itemsArray:[item_model]=[]
    var categoryArray:[category_model]=[]

    
    var imageArray=[UIImage(named: "lol"),UIImage(named: "lol"),UIImage(named: "lol"),UIImage(named: "lol"),UIImage(named: "lol")]
    
    @IBOutlet var textFieldView: UIView!
    
    @IBOutlet var bannerCollectionView: UICollectionView!
    @IBOutlet var categoryCollectionView: UICollectionView!
    @IBOutlet var itemsCollectionView: UICollectionView!
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        
        
        connect_server()
        
        textFieldView.layer.borderColor = UIColor.gray.cgColor
        textFieldView.layer.borderWidth = 0.5
        textFieldView.layer.cornerRadius = 3
        
        self.categoryCollectionView.dataSource=self
        self.categoryCollectionView.delegate=self
        self.bannerCollectionView.dataSource=self
        self.bannerCollectionView.delegate=self
        self.itemsCollectionView.dataSource=self
        self.itemsCollectionView.delegate=self
        
    }
    
    
    func connect_server(){
        
        let urlString = "https://run.mocky.io/v3/69ad3ec2-f663-453c-868b-513402e515f0"
        let request = NSMutableURLRequest(url: URL(string: urlString)!)
        request.httpMethod = "GET"
        let task = URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { data, response, error in
            guard error == nil && data != nil else {                                                          // check for fundamental networking error
                print("error=\(error!)")
                return
            }
            
            if let httpStatus = response as? HTTPURLResponse, httpStatus.statusCode != 200 {           // check for http errors
                print("statusCode should be 200, but is \(httpStatus.statusCode)")
                print("response = \(response!)")
            }
            
            let responseString = String(data: data!, encoding: String.Encoding.utf8)
            
            let priority = DispatchQueue.GlobalQueuePriority.default
            
            DispatchQueue.global(priority: priority).async
                {
                    DispatchQueue.main.async
                    {
                            self.parse_json(responseString!)
                    }
            }
            
        })
        task.resume()
    }
    
    
    func parse_json(_ data:String) {
        
        let data:NSString=data as NSString
        
        let datajson:Data=data.data(using: String.Encoding.utf8.rawValue)!
        
        do
        {
            let json = try JSONSerialization.jsonObject(with: datajson, options: .allowFragments) as! [String:AnyObject]
            
            newsarray = json["homeData"] as? [AnyObject]
            categoryData=newsarray![0]["values"]!! as? [AnyObject]
            bannerData=newsarray![1]["values"]!! as? [AnyObject]
            itemsData=newsarray![2]["values"]!! as? [AnyObject]
    
            self.categoryCollectionView.reloadData()
            self.bannerCollectionView.reloadData()
            self.itemsCollectionView.reloadData()
            
            for feed in categoryData! {
                let item:category_model=category_model()
                item.set(name: feed["name"] as? String, image_url: feed["image_url"] as? String)
                categoryArray.append(item)
            }
            
            for feed in bannerData! {
                let item:banner_model=banner_model()
                item.set(id: feed["id"] as? String, banner_url: feed["banner_url"] as? String)
                bannerArray.append(item)
            }
            for feed in itemsData! {
                let item:item_model=item_model()
                item.set(id: feed["id"] as? String, name: feed["name"] as? String, image: feed["image"] as? String, actual_price: feed["actual_price"] as? String, offer_price: feed["offer_price"] as? String, offer: feed["offer"] as? Int, is_express: feed["is_express"] as? Bool)
                itemsArray.append(item)
            }
            

        }
    
    
    catch
    {
        print("error serializing JSON: \(error)")
    }
    
        //print("lol", homedataarray["type"])
    
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == self.categoryCollectionView{
            return categoryArray.count
        }
        else if collectionView == self.bannerCollectionView{
            return bannerArray.count
        }
        else{
            return itemsArray.count
        }
        
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == self.categoryCollectionView{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "category", for: indexPath) as! categoryCollectionViewCell
            cell.catergoryImage.layer.cornerRadius = 35
            cell.catergoryImage.load(urlString: categoryArray[indexPath.row].image_url!)
            cell.categoryName.text=categoryArray[indexPath.row].name
            return cell
        }
        else if collectionView == self.bannerCollectionView{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "banner", for: indexPath) as! bannerCollectionViewCell
            cell.bannerImage.image = imageArray[indexPath.row]
            cell.bannerImage.layer.cornerRadius = 5
            cell.bannerImage.load(urlString: bannerArray[indexPath.row].banner_url!)
            return cell
        }
        else{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "itemcard", for: indexPath) as! itemCardCollectionViewCell
            cell.cardView.layer.borderWidth = 0.5
            cell.cardView.layer.borderColor = UIColor.gray.cgColor
            cell.cardView.layer.cornerRadius = 3
            
            cell.descriptionLabel.text = itemsArray[indexPath.row].name
            cell.oldPrizeLabel.text = itemsArray[indexPath.row].actual_price
            cell.newPrizeLabel.text = itemsArray[indexPath.row].offer_price
            cell.offerLabel.text = "\(itemsArray[indexPath.row].offer!)% OFF "
            cell.productImage.load(urlString: itemsArray[indexPath.row].image!)
            if itemsArray[indexPath.row].is_express == false{
                cell.expressImage.isHidden=true
            }
            else{
                cell.expressImage.isHidden=false
            }
            
            return cell
        }
    }

}
