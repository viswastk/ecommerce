//
//  item_model.swift
//  ecommerce
//
//  Created by viswas on 01/07/22.
//

import Foundation
class item_model
{
    var id:String?
    var name:String?
    var image:String?
    var actual_price:String?
    var offer_price:String?
    var offer:Int?
    var is_express:Bool?
    
    
    func set(id:String?,name:String?,image:String?,actual_price:String?,offer_price:String?,offer:Int?,is_express:Bool?)
    {
        self.id=id
        self.name=name
        self.image=image
        self.actual_price=actual_price
        self.offer_price=offer_price
        self.offer=offer
        self.is_express=is_express
    }
}
