//
//  banner_model.swift
//  ecommerce
//
//  Created by viswas on 01/07/22.
//

import Foundation
class banner_model
{
    var id:String?
    var banner_url:String?
    
    
    func set(id:String?,banner_url:String?)
    {
        self.id=id
        self.banner_url=banner_url
    }
}
